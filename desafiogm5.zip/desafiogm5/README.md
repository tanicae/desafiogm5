Tanita Caetano


## isnstruções necessárias para configuração
implementado com o nodejs
todos os pacotes necessarios foram instalados atraves do NPM



## Linguagens e frameworks usados
- JQuery
- Sass
- underscore
 

